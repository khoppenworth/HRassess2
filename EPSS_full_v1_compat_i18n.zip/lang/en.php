<?php
return [
  'app_name'=>'EPSS Self-Assessment','login'=>'Login','logout'=>'Logout','username'=>'Username','password'=>'Password',
  'dashboard'=>'Dashboard','admin'=>'Admin','users'=>'Users','questionnaires'=>'Questionnaires','start_assessment'=>'Start Assessment',
  'language'=>'Language','save'=>'Save','create'=>'Create','edit'=>'Edit','delete'=>'Delete','upload_logo'=>'Upload Logo'
];
