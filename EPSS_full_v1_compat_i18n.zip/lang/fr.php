<?php
return [
  'app_name'=>'Évaluation EPSS','login'=>'Connexion','logout'=>'Déconnexion','username'=>"Nom d’utilisateur",'password'=>'Mot de passe',
  'dashboard'=>'Tableau de bord','admin'=>'Admin','users'=>'Utilisateurs','questionnaires'=>'Questionnaires','start_assessment'=>'Démarrer',
  'language'=>'Langue','save'=>'Enregistrer','create'=>'Créer','edit'=>'Modifier','delete'=>'Supprimer','upload_logo'=>'Télécharger le logo'
];
