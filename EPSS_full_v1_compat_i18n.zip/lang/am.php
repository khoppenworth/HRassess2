<?php
return [
  'app_name'=>'EPSS ግምገማ','login'=>'መግቢያ','logout'=>'መውጫ','username'=>'የተጠቃሚ ስም','password'=>'የሚስጥር ቁጥር',
  'dashboard'=>'ዳሽቦርድ','admin'=>'አድሚን','users'=>'ተጠቃሚዎች','questionnaires'=>'መጠይቆች','start_assessment'=>'መጀመር',
  'language'=>'ቋንቋ','save'=>'ማስቀመጥ','create'=>'ፍጠር','edit'=>'አርትዕ','delete'=>'ሰርዝ','upload_logo'=>'አርማ አስገባ'
];
